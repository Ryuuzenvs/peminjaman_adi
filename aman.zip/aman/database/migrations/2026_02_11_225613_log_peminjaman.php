<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        // dr if ext
        DB::unprepared("DROP PROCEDURE IF EXISTS sp_log_activity");
        DB::unprepared("
        CREATE PROCEDURE sp_log_activity(IN pesan TEXT)
        BEGIN
            INSERT INTO activity_logs (data, created_at, updated_at)
            VALUES (pesan, NOW(), NOW());
        END
    ");
        // beg {} end
        // ev triger with call
        // 	Mendefinisikan parameter input (IN) bernama pesan dengan tipe data TEXT untuk stored procedure.

        // dr if ext
        DB::unprepared("DROP FUNCTION IF EXISTS hitung_denda");
        DB::unprepared("
        CREATE FUNCTION hitung_denda(tgl_pinjam DATETIME, tgl_kembali DATETIME) 
        RETURNS INT
        DETERMINISTIC
        BEGIN
            DECLARE selisih INT;
            DECLARE denda INT DEFAULT 0;
            
            SET selisih = DATEDIFF(tgl_kembali, tgl_pinjam);
            
            IF selisih > 3 THEN
                SET denda = (selisih - 3) * 1000;
            END IF;
            
            RETURN denda;
        END
    ");
        // ret must a int
        // be {} end
        // 

        DB::unprepared("DROP TRIGGER IF EXISTS trg_loans_insert");
        DB::unprepared("
        CREATE TRIGGER trg_loans_insert AFTER INSERT ON loans FOR EACH ROW
        BEGIN
            DECLARE v_username VARCHAR(255);
            DECLARE v_toolname VARCHAR(255);
            
            SELECT username INTO v_username FROM users WHERE id = NEW.borrower_id;
            SELECT name_tools INTO v_toolname FROM tools WHERE id = NEW.tool_id;
            
            CALL sp_log_activity(CONCAT('[BARU] ', v_username, ' mengajukan peminjaman alat: ', v_toolname));
        END
    ");
        DB::unprepared("DROP TRIGGER IF EXISTS trg_loans_update");
        DB::unprepared("
        CREATE TRIGGER trg_loans_update AFTER UPDATE ON loans FOR EACH ROW
        BEGIN
            DECLARE v_username VARCHAR(255);
            DECLARE v_toolname VARCHAR(255);
            DECLARE v_approver VARCHAR(255);
            
            SELECT username INTO v_username FROM users WHERE id = NEW.borrower_id;
            SELECT name_tools INTO v_toolname FROM tools WHERE id = NEW.tool_id;
            SELECT username INTO v_approver FROM users WHERE id = NEW.approved_by;

            -- Cek jika status berubah jadi Borrow (Approved)
            IF OLD.status = 'pending' AND NEW.status = 'borrow' THEN
                CALL sp_log_activity(CONCAT('[APPROVE] Peminjaman ', v_toolname, ' oleh ', v_username, ' disetujui oleh ', v_approver));
            
            -- Cek jika status berubah jadi Return (Kembali)
            ELSEIF OLD.status = 'borrow' AND NEW.status = 'return' THEN
                CALL sp_log_activity(CONCAT('[RETURN] ', v_username, ' telah mengembalikan ', v_toolname, '. Denda: Rp', NEW.penalty));

            -- Cek jika terjadi Soft Delete (deleted_at diisi)
            ELSEIF OLD.deleted_at IS NULL AND NEW.deleted_at IS NOT NULL THEN
                CALL sp_log_activity(CONCAT('[HAPUS] Data transaksi ', v_toolname, ' (Peminjam: ', v_username, ') dipindahkan ke sampah/soft delete'));
            END IF;
        END
    ");
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
