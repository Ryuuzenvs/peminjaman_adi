<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5>Tools List</h5>
        <div>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-warning btn-sm me-2">
                <i class='fa-solid fa-arrow-left'></i> Back
            </a>
            <a href="<?php echo e(route('tools.create')); ?>" class="btn btn-primary btn-sm">
                <i class='fa-solid fa-plus'></i> Create
            </a>
        </div>
    </div>

    <div class="card-body">
        <table class="table table-striped table-bordered align-middle">
            <thead>
                <tr>
                    <th class="text-start">Tool Name</th>
                    <th class="text-start">Category</th>
                    <th class="text-end">Stock</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-start"><?php echo e($t->name_tools); ?></td>
                    <td class="text-start"><?php echo e($t->category->nama_kategori ?? '-'); ?></td>
                    <td class="text-end"><?php echo e($t->stock); ?></td>
                    <td class="text-end">
                        <form method="POST" action="<?php echo e(route('tools.destroy', $t->id)); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm">
                                <i class='fa-solid fa-trash-can'></i> Delete
                            </button>
                        </form>
                        <a href="<?php echo e(route('tools.edit', $t->id)); ?>" class="btn btn-warning btn-sm">
                            <i class='fa-solid fa-pen-to-square'></i> Edit
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center text-muted">No tools found</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman_lar\resources\views/admin/tools/index.blade.php ENDPATH**/ ?>