<?php $__env->startSection('content'); ?>
<div class="card">
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="card-header d-flex justify-content-between align-items-center">
        <h5>Category List</h5>
        <div>
            <a class="btn btn-warning btn-sm me-2" href="<?php echo e(route('admin.dashboard')); ?>">
                <i class='fas fa-arrow-left'></i> Back
            </a>
            <a class="btn btn-primary btn-sm" href="<?php echo e(route('category.create')); ?>">
                <i class='fa-solid fa-plus'></i> Create
            </a>
        </div>
    </div>

    <div class="card-body">
        <table class="table table-striped text-center">
            <thead>
                <tr>
                    <th>Category</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($c->nama_kategori); ?></td>
                        <td>
                            <form method="post" action="<?php echo e(route('category.destroy', $c->id)); ?>" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm">
                                    <i class='fa-solid fa-trash-can'></i>
                                </button>
                            </form>
                            <a href="<?php echo e(route('category.edit', $c->id)); ?>" class="btn btn-warning btn-sm">
                                <i class='fa-solid fa-pen-to-square'></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="2" class="text-center text-muted">No categories found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman_lar\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>