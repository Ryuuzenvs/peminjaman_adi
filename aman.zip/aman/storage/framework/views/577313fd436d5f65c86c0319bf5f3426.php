<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>All Loan Management</h2>
            <span>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary btn-sm">
                    <i class='fas fa-arrow-left'></i> Back
                </a>
                <a href="<?php echo e(route('admin.loans.create')); ?>" class="btn btn-primary btn-sm">
                    <i class='fa-solid fa-plus'></i> Create
                </a>
            </span>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="card shadow">
            <div class="card-body">
                <table class="table table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Borrower</th>
                            <th>Tool</th>
                            <th>Loan Date</th>
                            <th>Return Date</th>
                            <th>Status</th>
                            <th>Penalty</th>
                            <th>Admin Name</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?php echo e($l->id); ?></strong></td>
                                <td><strong><?php echo e($l->borrower->username); ?></strong></td>
                                <td><?php echo e($l->tool->name_tools ?? 'Deleted Tool'); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($l->loan_date)->format('d M Y')); ?></td>
                                <td>
                                    <?php echo e($l->return_date ? \Carbon\Carbon::parse($l->return_date)->format('d M Y') : 'No Data'); ?>

                                </td>
                                <td>
                                    <?php if($l->status == 'pending'): ?>
                                        <span class="text-warning">PENDING</span>
                                    <?php elseif($l->status == 'borrow'): ?>
                                        <span class="text-primary">BORROWED</span>
                                    <?php else: ?>
                                        <span class="text-success">RETURNED</span>
                                    <?php endif; ?>
                                </td>
                                <td><span class="text-danger">Rp <?php echo e(number_format($l->penalty)); ?></span></td>
                                <td><small><?php echo e($l->approver->username ?? 'No Admin'); ?></small></td>
                                <td><?php echo e(\Carbon\Carbon::parse($l->created_at)->format('d M Y H:i:s')); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <form action="<?php echo e(route('loans.destroy', $l->id)); ?>" method="POST"
                                            onsubmit="return confirm('Delete this transaction? Stock will be adjusted automatically.')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                            <a href="<?php echo e(route('admin.loans.edit', $l->id)); ?>" class="btn btn-warning btn-sm">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </a>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <div class="d-flex justify-content-center align-items-center">
                    <?php echo e($loans->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\aman\resources\views/admin/loans/index.blade.php ENDPATH**/ ?>