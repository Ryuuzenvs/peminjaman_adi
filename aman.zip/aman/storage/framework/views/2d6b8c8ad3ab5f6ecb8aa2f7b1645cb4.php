<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-header bg-dark text-white">
        Loans
    </div>

    <div class="card-body">
        <table class="table table-striped align-middle">
            <thead class="table-light">
                <tr>
                    <th class="text-start">Tool</th>
                    <th class="text-center">Status</th>
                    <th class="text-end">Loan Date</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $myloan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>

                    <td class="text-start fw-semibold">
                        <?php echo e($loan->tool->name_tools); ?>

                    </td>

                    <td class="text-center">
                        <?php if($loan->status == 'pending'): ?>
                            <span class="badge bg-secondary">
                                waiting ACC
                            </span>

                        <?php elseif($loan->request_return_date): ?>
                            <span class="badge bg-warning text-dark">
                                Request Return
                            </span>

                        <?php else: ?>
                            <span class="badge bg-success">
                                borrowed
                            </span>
                        <?php endif; ?>
                    </td>

                    <td class="text-end text-muted">
                        <?php echo e($loan->created_at->format('d M Y H:i:s')); ?>

                    </td>

                    <td class="text-center">
                        <?php if($loan->status == 'borrow' && !$loan->request_return_date): ?>
                            <form action="<?php echo e(route('loans.requestReturn', $loan->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">
                                    Ajukan Pengembalian
                                </button>
                            </form>

                        <?php elseif($loan->request_return_date): ?>
                            <span class="text-muted small">
                                Menunggu Verifikasi
                            </span>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center text-muted">
                        Tidak ada pinjaman aktif
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\aman\resources\views/peminjam/index.blade.php ENDPATH**/ ?>