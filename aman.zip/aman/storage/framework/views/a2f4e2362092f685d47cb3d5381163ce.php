<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-header bg-success text-white">
        History
    </div>

    <div class="card-body">
        <table class="table table-striped align-middle">
            <thead class="table-light">
                <tr>
                    <th class="text-start">Tool</th>
                    <th class="text-end">Loan Date</th>
                    <th class="text-end">Return date</th>
                    <th class="text-end">penalty</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-start fw-semibold">
                        <?php echo e($h->tool->name_tools); ?>

                    </td>

                    <td class="text-end text-muted">
                        <?php echo e($h->loan_date ? \Carbon\Carbon::parse($h->loan_date)->format('d M Y H:i') : '-'); ?>

                    </td>

                    <td class="text-end text-muted">
                        <?php echo e($h->return_date ? \Carbon\Carbon::parse($h->return_date)->format('d M Y H:i') : '-'); ?>

                    </td>

                    <td class="text-end fw-semibold">
                        Rp <?php echo e(number_format($h->penalty, 0, ',', '.')); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center text-muted">
                        Empty
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman_lar (1)\peminjaman_lar\resources\views/peminjam/return.blade.php ENDPATH**/ ?>