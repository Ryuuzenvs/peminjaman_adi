<?php $__env->startSection('content'); ?>
<div class="card shadow-sm">
    <div class="card-body p-4">
        <div class="d-flex justify-content-start mb-3">
            <a href="<?php echo e(route('category.index')); ?>" class="btn btn-warning">
                <i class='fas fa-arrow-left'></i> Back
            </a>
        </div>

        <h3 class="text-center mb-4">Create Category</h3>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('category.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label">Category Name</label>
                <input type="text" name="nama_kategori" class="form-control" required>
            </div>

            <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-primary">
                    <i class='fa-solid fa-plus'></i> Create
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\peminjaman_lar\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>