<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Aplikasi Peminjaman</title>
    <link href="<?php echo e(asset('bootstrap.min.css')); ?>" rel="stylesheet">
    <style>
        html,
        body {
            height: 100%;
            margin: 0;
            overflow: hidden;
        }

        #jarak {
            /* margin-bottom: 100px !important; */
        }
    </style>
</head>

<body class="bg-light d-flex justify-content-center align-items-center">

    <div style="width: 100%; max-width: 350px;" class="px-3">
        <img src="https://png.pngtree.com/png-clipart/20240525/original/pngtree-cute-hand-drawn-cartoon-school-stuff-sticker-set-vector-png-image_15177551.png"
            class="img-fluid d-block mx-auto mb-5" id="jarak" style="height: 100px; width: auto; "
            alt="Logo Sekolah">

        <div class="card shadow-sm border-0" style="border-radius: 15px;">
            <div class="card-body p-4">


                <h3 class="text-center mb-4">Login</h3>

                <?php if(session('success')): ?>
                    <div class="alert alert-success py-2"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger py-2"><?php echo e(session('error')); ?></div>
                <?php endif; ?>

                <form action="<?php echo e(route('login.post')); ?>" method="POST" id="loginForm">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" placeholder="exam" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" id="password"
                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Masukkan password"
                            required>

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div id="passwordError" class="invalid-feedback" style="display: none;">
                            Password minimal 8 karakter.
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-2" id="loginBtn">Login</button>
                </form>

            </div>

        </div>
        <div src="" class="img-fluid d-block mx-auto mb-3" style="height: 300px; width: auto;" alt=""></div>

    </div>

    <script>
        document.getElementById('loginForm').onsubmit = function(e) {
            const passwordInput = document.getElementById('password');
            const passwordError = document.getElementById('passwordError');
            const btn = document.getElementById('loginBtn');

            if (passwordInput.value.length < 8) {
                e.preventDefault();
                passwordInput.classList.add('is-invalid');
                passwordError.style.display = 'block';
                return false;
            }

            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Memproses...';
            btn.classList.add('opacity-50');
        };

        document.getElementById('password').oninput = function() {
            this.classList.remove('is-invalid');
            document.getElementById('passwordError').style.display = 'none';
        };
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\aman\resources\views/auth/login.blade.php ENDPATH**/ ?>