<?php $__env->startSection('content'); ?>
<h3 class="mb-3">Loans Manegement</h3>

<div class="card shadow-sm">
    <div class="card-body">
        <table class="table table-bordered table-hover align-middle bg-white">
            <thead class="table-light">
                <tr>
                    <th class="text-start">Borrower</th>
                    <th class="text-start">Tool</th>
                    <th class="text-end">Loan date</th>
                    <th class="text-end">Deadline</th>
                    <th class="text-center">Status</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-start fw-semibold">
                        <?php echo e($l->borrower->username); ?>

                    </td>

                    <td class="text-start">
                        <?php echo e($l->tool->name_tools ?? 'Alat Dihapus'); ?>

                    </td>

                    <td class="text-end text-muted">
                        <?php echo e($l->created_at->format('d M Y H:i:s')); ?>

                    </td>

                    <td class="text-end">
                        <?php echo e($l->loan_date ? \Carbon\Carbon::parse($l->created_at)->addDays(3)->format('d M Y H:i:s') : '-'); ?>

                    </td>

                    <td class="text-center">
                        <span class="badge 
                            <?php echo e($l->status == 'pending' ? 'bg-warning text-dark' : 
                               ($l->status == 'borrow' ? 'bg-info text-dark' : 'bg-success')); ?>">
                            <?php echo e(ucfirst($l->status)); ?>

                        </span>
                    </td>

                    <td class="text-end">
                        <?php if($l->status == 'pending'): ?>
                            <form action="<?php echo e(route('loans.approve', $l->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                <button class="btn btn-sm btn-primary">
                                    Approve
                                </button>
                            </form>

                        <?php elseif($l->status == 'borrow'): ?>
                            <form action="<?php echo e(route('loans.return', $l->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                <button class="btn btn-sm btn-success">
                                    Terima Kembali
                                </button>
                            </form>

                        <?php else: ?>
                            <span class="text-muted small">
                                Return <br>
                                Rp <?php echo e(number_format($l->penalty, 0, ',', '.')); ?>

                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<a href="<?php echo e(route('officer.report')); ?>" class="btn btn-primary mt-3">
   Print Report
</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\aman\resources\views/petugas/index.blade.php ENDPATH**/ ?>