<link href=<?php echo e(asset('bootstrap.min.css')); ?> rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<link rel="stylesheet" href="<?php echo e(asset('fas/css/all.min.css')); ?>">

<script src="<?php echo e(asset('bootstrap.bundle.min.js')); ?>"></script>



<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">

        <div class="container">
            <?php
                $user = Auth::user();
            ?>
            <a class="navbar-brand" href="<?php echo e($user ? route($user->role . '.dashboard') : '#'); ?>">
                PinjamAlat
            </a>

            <div class="navbar-nav">
                <?php if($user && $user->role === 'admin'): ?>
                    <a class="nav-link" href="<?php echo e(route('category.index')); ?>">Category</a>
                    <a class="nav-link" href="<?php echo e(route('tools.index')); ?>">Tool</a>
                    <a class="nav-link" href="<?php echo e(route('users.index')); ?>">User</a>
                    <a class="nav-link" href="<?php echo e(route('admin.loans.index')); ?>">Loan</a>
                    <a class="nav-link" href="<?php echo e(route('admin.logs.index')); ?>">Logs</a>
                <?php elseif($user && $user->role === 'officer'): ?>
                    <a class="nav-link" href="<?php echo e(route('officer.dashboard')); ?>">Manegement</a>
                    <a class="nav-link" href="<?php echo e(route('officer.report')); ?>">Report</a>
                <?php elseif($user && $user->role === 'borrower'): ?>
                    <a class="nav-link" href="<?php echo e(route('borrower.dashboard')); ?>">My Loans</a>
                    <a class="nav-link" href="<?php echo e(route('borrower.pinjam')); ?>">Get Loans</a>
                    <a class="nav-link" href="<?php echo e(route('borrower.history')); ?>">Get Return</a>
                <?php endif; ?>
                <form action="<?php echo e(route('logout')); ?>" method="post" class="d-inline">
                    <?php if(auth()->guard()->check()): ?>
                        <form action="<?php echo e(route('logout')); ?>" method="post" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-link nav-link">Logout (<?php echo e($user->username); ?>)</button>
                        </form>
                    <?php endif; ?>
                </form>
            </div>
        </div>

    </nav>

    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
<?php /**PATH C:\xampp\htdocs\peminjaman_lar\resources\views/app.blade.php ENDPATH**/ ?>