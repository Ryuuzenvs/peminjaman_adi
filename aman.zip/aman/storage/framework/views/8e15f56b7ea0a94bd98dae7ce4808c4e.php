<?php $__env->startSection('content'); ?>
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">Get loan</div>
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 mb-3">
                        <div class="card border-primary">
                            <div class="card-body">
                                <h5><?php echo e($t->name_tools); ?></h5>
                                <p>Stock: <strong><?php echo e($t->stock); ?></strong></p>
                                <form action="<?php echo e(route('pinjam.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="tool_id" value="<?php echo e($t->id); ?>">
                                    <button type="button" class="btn btn-primary w-100" data-bs-toggle="modal"
                                        data-bs-target="#confirmModal<?php echo e($t->id); ?>">
                                        Loan
                                    </button>
                                    <!-- Modal -->
                                    <div class="modal fade" id="confirmModal<?php echo e($t->id); ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">

                                                <div class="modal-header bg-primary text-white">
                                                    <h5 class="modal-title">Konfirmasi Pinjaman</h5>
                                                    <button type="button" class="btn-close btn-close-white"
                                                        data-bs-dismiss="modal"></button>
                                                </div>

                                                <div class="modal-body text-center">
                                                    <p>Yakin ingin meminjam alat:</p>
                                                    <h5 class="fw-bold"><?php echo e($t->name_tools); ?></h5>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">
                                                        Batal
                                                    </button>

                                                    <form action="<?php echo e(route('pinjam.store')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="tool_id" value="<?php echo e($t->id); ?>">
                                                        <button type="submit" class="btn btn-primary">
                                                            Ya, Pinjam
                                                        </button>
                                                    </form>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\aman\resources\views/peminjam/loan.blade.php ENDPATH**/ ?>